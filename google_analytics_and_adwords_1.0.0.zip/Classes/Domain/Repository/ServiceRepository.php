<?php

namespace Adswerve\GoogleAnalyticsAndAdwords\Domain\Repository;

/**
 * Class ServiceRepository
 *
 * @package Adswerve\GoogleAnalyticsAndAdwords\Domain\Repository
 */
class ServiceRepository extends \TYPO3\CMS\Extbase\Persistence\Repository
{

}
