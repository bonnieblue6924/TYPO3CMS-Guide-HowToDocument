<?php

return [
    'dependencies' => [
        'backend',
        'core',
    ],
    'imports' => [
        '@typo3/belog/' => 'EXT:belog/Resources/Public/JavaScript/',
    ],
];
