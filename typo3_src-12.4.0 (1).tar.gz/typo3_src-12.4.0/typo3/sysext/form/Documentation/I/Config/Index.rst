.. include:: /Includes.rst.txt


.. _configurationreference:

=======================
Configuration Reference
=======================

This chapter is a complete reference of the possible configuration settings.
It addresses your concerns as and integrator and developer.

.. toctree::

   persistenceManager/Index
   proto/Index
   formManager/Index
