<?php

\TYPO3\CMS\Extbase\Utility\ExtensionUtility::registerPlugin(
    'Adswerve.GoogleAnalyticsAndAdwords',
    'GoogleServices',
    'Google Marketing Services',
    'EXT:google_analytics_and_adwords/Resources/Public/Icons/Extension.svg'
);
